# ============================
# 🎯 Donation Prediction Dashboard (Simplified - No Graphs)
# ============================

import dash
from dash import dcc, html, Input, Output, State
import dash_bootstrap_components as dbc
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import traceback

# ---------------------------
# 1. Load & preprocess data
# ---------------------------
try:
    df = pd.read_csv('cleaned_census.csv')
    required_columns = ['donate', 'age']
    if not all(col in df.columns for col in required_columns):
        raise ValueError(f"Missing required columns: {set(required_columns) - set(df.columns)}")
    print("✅ Data loaded successfully.")
except Exception as e:
    raise Exception(f"❌ Data loading error: {str(e)}")

# Encode categoricals
df_encoded = pd.get_dummies(df, drop_first=False)
X = df_encoded.drop('donate', axis=1)
y = df_encoded['donate']

# Split + train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
feature_names = X_train.columns

# Extract dropdown options
workclass_columns = [col for col in df_encoded.columns if col.startswith('workclass_')]
country_columns = [col for col in df_encoded.columns if col.startswith('native-country_')]

workclass_options = [{'label': col.replace('workclass_', '').replace('_', ' '),
                      'value': col.replace('workclass_', '')} for col in workclass_columns]
country_options = [{'label': col.replace('native-country_', '').replace('_', ' '),
                    'value': col.replace('native-country_', '')} for col in country_columns]

# ---------------------------
# 2. Dash App Layout
# ---------------------------
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Donation Prediction Dashboard"

app.layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H1("💰 Donation Prediction", className="text-center mb-4"),
            html.P("Enter your information to predict donation likelihood.", className="lead text-center"),
            html.Hr(),

            dbc.Form([
                dbc.Label("Age"),
                dcc.Slider(id='input-age', min=0, max=100, step=1, value=30,
                           marks={i: str(i) for i in range(0, 101, 20)}),

                dbc.Label("Education Level (education-num)"),
                dcc.Slider(id='input-education-num', min=0, max=16, step=1, value=10,
                           marks={i: str(i) for i in range(0, 17, 2)}),

                dbc.Label("Capital Gain"),
                dcc.Slider(id='input-capital-gain', min=0, max=100000, step=1000, value=0,
                           marks={i: f'{i//1000}k' for i in range(0, 100001, 20000)}),

                dbc.Label("Capital Loss"),
                dcc.Slider(id='input-capital-loss', min=0, max=5000, step=100, value=0,
                           marks={i: str(i) for i in range(0, 5001, 1000)}),

                dbc.Label("Hours per Week"),
                dcc.Slider(id='input-hours-per-week', min=0, max=100, step=1, value=40,
                           marks={i: str(i) for i in range(0, 101, 20)}),

                dbc.Label("Workclass"),
                dcc.Dropdown(id='input-workclass', options=workclass_options,
                             placeholder="Select workclass"),

                dbc.Label("Native Country"),
                dcc.Dropdown(id='input-native-country', options=country_options,
                             placeholder="Select country"),

                html.Br(),
                dbc.Button("Predict Donation", id="predict-button", color="primary", n_clicks=0,
                           className="w-100"),
                html.Div(id="prediction-output", className="mt-4 text-center"),
            ])
        ], width=6, className="mx-auto mt-5")
    ])
], fluid=True)

# ---------------------------
# 3. Prediction Callback
# ---------------------------
@app.callback(
    Output('prediction-output', 'children'),
    Input('predict-button', 'n_clicks'),
    State('input-age', 'value'),
    State('input-education-num', 'value'),
    State('input-capital-gain', 'value'),
    State('input-capital-loss', 'value'),
    State('input-hours-per-week', 'value'),
    State('input-workclass', 'value'),
    State('input-native-country', 'value')
)
def make_prediction(n_clicks, age, edu, gain, loss, hrs, workclass, country):
    if n_clicks > 0:
        try:
            input_data = pd.DataFrame(columns=feature_names)
            input_data.loc[0] = 0

            # Fill numerical inputs
            input_data.at[0, 'age'] = age
            input_data.at[0, 'education-num'] = edu
            input_data.at[0, 'capital-gain'] = gain
            input_data.at[0, 'capital-loss'] = loss
            input_data.at[0, 'hours-per-week'] = hrs

            # Handle categorical one-hot columns
            if workclass:
                wc = f'workclass_{workclass}'
                if wc in input_data.columns:
                    input_data.at[0, wc] = 1

            if country:
                cc = f'native-country_{country}'
                if cc in input_data.columns:
                    input_data.at[0, cc] = 1

            # Make prediction
            prediction = rf_model.predict(input_data)
            probability = rf_model.predict_proba(input_data)[:, 1][0]

            if prediction[0] == 1:
                return dbc.Alert(f"✅ Likely to Donate (Probability: {probability:.2f})", color="success")
            else:
                return dbc.Alert(f"⚠️ Not Likely to Donate (Probability: {probability:.2f})", color="warning")

        except Exception as e:
            return dbc.Alert(f"Error: {str(e)}", color="danger")

    return "Click the button to get a prediction."

# ---------------------------
# 4. Run App
# ---------------------------
if __name__ == '__main__':
    app.run(debug=True)
